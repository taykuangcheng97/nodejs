const mongoose = require('mongoose');

var Rawtext = mongoose.model('rawtext', {
    sentence: { type: String },
    status: { type: String },
});

module.exports = { Rawtext };