const mongoose = require('mongoose');

var Wordnet = mongoose.model('wordnet', {
    word: { type: String },
    definition: { type: String }
});

module.exports = { Wordnet };