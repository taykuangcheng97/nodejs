const mongoose = require('mongoose');

var Transtext = mongoose.model('transtext', {
    ori_sentence: { type: String },
    trans_sentence: { type: String }
});

module.exports = { Transtext };