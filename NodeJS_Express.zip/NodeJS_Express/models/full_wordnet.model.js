const mongoose = require('mongoose');

var Fullwordnet = mongoose.model('full_wordnet', {
    index: { type: String },
    word: { type: String }
});

module.exports = { Fullwordnet };