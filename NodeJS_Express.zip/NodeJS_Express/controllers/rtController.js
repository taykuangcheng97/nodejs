const mongoose = require('mongoose');
const express = require('express');
var router = express.Router();
var { Rawtext } = require('../models/rawtext.model');
var { Wordnet } = require('../models/wordnet.model');
var { Transtext } = require('../models/transtext.model');
var { Fullwordnet } = require('../models/full_wordnet.model');


router.get('/', (req, res) => {
    res.render("rawtext/addOrEdit", {
        viewTitle: "Insert Rawtext"
    });
});

router.get('/translator', (req, res) => {
    Rawtext.findOne({status: 'f'}, (err, docs) => {
        if (!err) {
            res.render("rawtext/translator", {
                list: docs
            });
        }
        else {
            console.log('Error in retrieving rawtext list :' + err);
        }
    });
});


router.post('/', (req, res) => {
    if (req.body._id == '')
        insertRecord(req, res);
    else
        updateRecord(req, res);
});

router.post('/translated', (req, res) => {
    insertTranslation(req, res);
});

function checkExist_thenInsert(ori_phrase, trans_phrase, lang_hidden){
    Fullwordnet.find({word : ori_phrase}, function (err, docs) {
        // if the word is found, or there is no translation matched to the original text
        if (docs.length || trans_phrase == 0){
            // ignore
        }
        // call insert function
        else{
            insertPhrase(ori_phrase, trans_phrase, lang_hidden);
        }
    });
}

// to insert phrase
function insertPhrase(ori_phrase, trans_phrase, lang_hidden){
    new_phrase = { word: ori_phrase, [lang_hidden+"_definition"]: trans_phrase };
    // Insert phrases
    Wordnet.collection.insertOne(new_phrase, function (err, docs) {
        if (err){ 
            return console.error(err);
        } else {
          console.log("Successfully insert new phrases!");
        }
    }); 
}

//insert phrase and sentence
function insertTranslation(req, res){

    var lang_hidden = req.body.lang_hidden;
    var full_json = JSON.parse(req.body.full_json);
    //res.jsonp(full_json[0].length);

    for (var i = 0; i < full_json[0].length; i++){
        checkExist_thenInsert(full_json[0][i], full_json[1][i], lang_hidden);
    }

    // Insert translated sentence
    var new_sentence = { ori_sentence: req.body.ori_txt, [lang_hidden+"_sentence"]: req.body.trans_txt };
    Transtext.collection.insertOne(new_sentence, function (err, docs) {
        if (err){ 
            return console.error(err);
        } else {
          console.log("Successfully insert new sentence!");
          res.redirect('translator');
        }
    });
}


function insertRecord(req, res) {
    var rawtext = new Rawtext();
    rawtext.sentence = req.body.sentence;
    rawtext.status = req.body.status;
    rawtext.save((err, doc) => {
        if (!err)
            res.redirect('rawtext/list');
        else {
            if (err.name == 'ValidationError') {
                handleValidationError(err, req.body);
                res.render("rawtext/addOrEdit", {
                    viewTitle: "Insert Rawtext",
                    rawtext: req.body
                });
            }
            else
                console.log('Error during record insertion : ' + err);
        }
    });
}

function updateRecord(req, res) {
    Rawtext.findOneAndUpdate({ _id: req.body._id }, req.body, { new: true }, (err, doc) => {
        if (!err) { res.redirect('rawtext/list'); }
        else {
            if (err.name == 'ValidationError') {
                handleValidationError(err, req.body);
                res.render("rawtext/addOrEdit", {
                    viewTitle: 'Update Rawtext',
                    rawtext: req.body
                });
            }
            else
                console.log('Error during record update : ' + err);
        }
    });
}


router.get('/list', (req, res) => {
    Rawtext.find((err, docs) => {
        if (!err) {
            res.render("rawtext/list", {
                list: docs
            });
        }
        else {
            console.log('Error in retrieving rawtext list :' + err);
        }
    });
});


function handleValidationError(err, body) {
    for (field in err.errors) {
        switch (err.errors[field].path) {
            case 'sentence':
                body['sentenceError'] = err.errors[field].message;
                break;
            case 'status':
                body['statusError'] = err.errors[field].message;
                break;
            default:
                break;
        }
    }
}

router.get('/:id', (req, res) => {
    Rawtext.findById(req.params.id, (err, doc) => {
        if (!err) {
            res.render("rawtext/addOrEdit", {
                viewTitle: "Update Rawtext",
                rawtext: doc
            });
        }
    });
});

router.get('/delete/:id', (req, res) => {
    Rawtext.findByIdAndRemove(req.params.id, (err, doc) => {
        if (!err) {
            res.redirect('/rawtext/list');
        }
        else { console.log('Error in rawtext delete :' + err); }
    });
});

module.exports = router;